
// Script vacío (no usado directamente por index actual)
